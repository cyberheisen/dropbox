#!/bin/python
# program description

import sys

def readfile(filename):
    f = open(filename,"r")
    lines = f.readlines()
    return lines

def fixPrint(code):
    for c in code:
        if "print" in c:
            c_list = c.split(" ")
            for cl in c_list:
                print(cl)
            exit()
def main():
    filename = "./test.txt" #sys.argv[1]
    code = readfile(filename)
    fixPrint(code)
    exit()

if __name__== "__main__":
    main()
